module AlertsHelper
end
