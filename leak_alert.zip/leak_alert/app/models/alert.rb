class Alert < ActiveRecord::Base
  belongs_to :sensor
end
