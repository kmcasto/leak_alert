class Agent < ActiveRecord::Base
end
