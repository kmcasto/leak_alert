require 'test_helper'

class AgentsHelperTest < ActionView::TestCase
end
