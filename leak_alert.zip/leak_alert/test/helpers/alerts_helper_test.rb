require 'test_helper'

class AlertsHelperTest < ActionView::TestCase
end
